Emma Meersman
Graphics
Final Project

OpenGL Rendering Game - Tigger's Island Adventure

Oh no! Tigger has gotten himself stranded on an island in the very middle of the ocean! For some strange reason, the island is littered with teapots. Using his ingenious engineering skills, Tigger thinks that he can build a hot air balloon out of teapots. After all, anything is possible when you're Tigger. 

Help Tigger bounce around the island to collect all the teapots and escape. Once you get the teapots, guide Tigger to his newly constructed craft and watch him fly away to parts unknown. Bon voyage, Tigger!


Controls:

W, A, S, D - forward, back, and turning